Add-Type -AssemblyName PresentationFramework

[System.Windows.MessageBox]::Show('Mark is awesome!', 'PowerShell Message Box', 'OK', 'Information')
