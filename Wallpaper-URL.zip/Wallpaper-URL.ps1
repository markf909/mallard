$url = "https://raw.githubusercontent.com/markf909/mallard/main/Muppet.jpg"
$downloadPath = [System.IO.Path]::Combine($env:USERPROFILE, 'Downloads\Muppet.jpg')

try {
    Invoke-WebRequest -Uri $url -OutFile $downloadPath
    Write-Host "Download successful. File saved to: $downloadPath"
    Set-DesktopBackground $downloadPath
} catch {
    Write-Host "Download failed. Error: $_"
}

Read-Host "Press Enter to close this window"
